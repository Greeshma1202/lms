/**
 * JSON/REST proxy — all non-upload API calls go through here.
 */

const TIMEOUT_MS = 90_000;

export const config = {
  api: {
    bodyParser: false,
    responseLimit: '10mb',
  },
};

function readRawBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', chunk => chunks.push(chunk));
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

export default async function handler(req, res) {
  // Read at request time so env vars are always fresh
  const BASE_URL = process.env.BACKEND_URL || 'http://localhost:8000';

  /* ── 1. Build target URL ─────────────────────────────────────────── */
  const segments = req.query.path;
  const rest     = Array.isArray(segments) ? segments.join('/') : (segments ?? '');
  // Strip trailing slash — FastAPI redirects trailing-slash URLs with 308
  const cleanRest = rest.replace(/\/$/, '');
  const qs       = new URLSearchParams(
    Object.entries(req.query).filter(([k]) => k !== 'path')
  ).toString();
  const target = `${BASE_URL}/${cleanRest}${qs ? `?${qs}` : ''}`;

  console.log(`[proxy] ${req.method} ${target}`);

  /* ── 2. Forward headers ──────────────────────────────────────────── */
  const SKIP_REQ = new Set([
    'host', 'connection', 'transfer-encoding',
    'x-forwarded-for', 'x-forwarded-host', 'x-forwarded-proto',
    // Strip conditional headers so upstream always returns 200, not 304
    'if-none-match', 'if-modified-since', 'if-match',
    'if-unmodified-since', 'if-range',
  ]);
  const fwdHeaders = {};
  for (const [k, v] of Object.entries(req.headers)) {
    if (!SKIP_REQ.has(k.toLowerCase())) fwdHeaders[k] = v;
  }

  /* ── 3. Read raw body and forward as-is ─────────────────────────── */
  let body;
  if (!['GET', 'HEAD'].includes(req.method)) {
    try {
      body = await readRawBody(req);
      if (body.length === 0) body = undefined;
      // Set Content-Length from actual body
      if (body) fwdHeaders['content-length'] = body.length.toString();
    } catch {
      body = undefined;
    }
  }

  // DELETE: no body, no Content-Type
  if (req.method === 'DELETE') {
    delete fwdHeaders['content-type'];
    body = undefined;
    delete fwdHeaders['content-length'];
  }

  /* ── 4. Hit the upstream ─────────────────────────────────────────── */
  let upstream;
  const maxRetries = 3;
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      upstream = await fetch(target, {
        method:  req.method,
        headers: fwdHeaders,
        body,
        signal:  AbortSignal.timeout(TIMEOUT_MS),
        redirect: 'follow',
      });
      break; // Success, exit loop
    } catch (err) {
      const isTimeout = err.name === 'TimeoutError' || err.name === 'AbortError';
      console.error(`[proxy] upstream error (attempt ${attempt}/${maxRetries}):`, err.message);
      if (attempt === maxRetries || isTimeout) {
        return res.status(504).json({
          detail: isTimeout
            ? 'Server is waking up (Render cold start). Please wait and retry.'
            : `Network error: ${err.message}`,
        });
      }
      // Wait 2 seconds before retry
      await new Promise(resolve => setTimeout(resolve, 2000));
    }
  }

  /* ── 5. Forward response ─────────────────────────────────────────── */
  const SKIP_RES = new Set([
    'transfer-encoding', 'content-encoding',
    'content-length', 'connection', 'keep-alive',
    // Don't forward cache headers — API responses should never be cached by the browser
    'etag', 'last-modified', 'cache-control', 'expires', 'pragma',
  ]);
  for (const [k, v] of upstream.headers.entries()) {
    if (!SKIP_RES.has(k.toLowerCase())) res.setHeader(k, v);
  }
  // Explicitly tell the browser not to cache API responses
  res.setHeader('Cache-Control', 'no-store');

  res.status(upstream.status);
  const buf = await upstream.arrayBuffer();
  res.end(Buffer.from(buf));
}
